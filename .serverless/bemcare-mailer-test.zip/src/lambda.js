/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/app.module.ts":
/*!***************************!*\
  !*** ./src/app.module.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.AppModule = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst app_service_1 = __webpack_require__(/*! ./app.service */ \"./src/app.service.ts\");\nconst jwt_1 = __webpack_require__(/*! @nestjs/jwt */ \"@nestjs/jwt\");\nconst jwt_strategy_1 = __webpack_require__(/*! ./auth/strategies/jwt.strategy */ \"./src/auth/strategies/jwt.strategy.ts\");\nconst provider_module_1 = __webpack_require__(/*! ./provider/provider.module */ \"./src/provider/provider.module.ts\");\nconst { JWT_SECRET } = process.env;\nlet AppModule = class AppModule {\n};\nAppModule = __decorate([\n    (0, common_1.Module)({\n        imports: [\n            jwt_1.JwtModule.register({\n                secret: JWT_SECRET,\n            }),\n            provider_module_1.ProviderModule\n        ],\n        providers: [\n            app_service_1.AppService,\n            jwt_strategy_1.JwtStrategy\n        ],\n    })\n], AppModule);\nexports.AppModule = AppModule;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/app.module.ts?");

/***/ }),

/***/ "./src/app.service.ts":
/*!****************************!*\
  !*** ./src/app.service.ts ***!
  \****************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.AppService = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nlet AppService = class AppService {\n    getHello() {\n        return 'Hello World!';\n    }\n};\nAppService = __decorate([\n    (0, common_1.Injectable)()\n], AppService);\nexports.AppService = AppService;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/app.service.ts?");

/***/ }),

/***/ "./src/auth/strategies/jwt-auth.guard.ts":
/*!***********************************************!*\
  !*** ./src/auth/strategies/jwt-auth.guard.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.JwtAuthGuard = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst passport_1 = __webpack_require__(/*! @nestjs/passport */ \"@nestjs/passport\");\nlet JwtAuthGuard = class JwtAuthGuard extends (0, passport_1.AuthGuard)('jwt') {\n};\nJwtAuthGuard = __decorate([\n    (0, common_1.Injectable)()\n], JwtAuthGuard);\nexports.JwtAuthGuard = JwtAuthGuard;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/auth/strategies/jwt-auth.guard.ts?");

/***/ }),

/***/ "./src/auth/strategies/jwt.strategy.ts":
/*!*********************************************!*\
  !*** ./src/auth/strategies/jwt.strategy.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nvar __metadata = (this && this.__metadata) || function (k, v) {\n    if (typeof Reflect === \"object\" && typeof Reflect.metadata === \"function\") return Reflect.metadata(k, v);\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.JwtStrategy = void 0;\nconst passport_jwt_1 = __webpack_require__(/*! passport-jwt */ \"passport-jwt\");\nconst passport_1 = __webpack_require__(/*! @nestjs/passport */ \"@nestjs/passport\");\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst module_config_1 = __webpack_require__(/*! ../../config/module.config */ \"./src/config/module.config.ts\");\n(0, module_config_1.ConfigModuleForRoot)();\nconst { JWT_SECRET } = process.env;\nlet JwtStrategy = class JwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy) {\n    constructor() {\n        super({\n            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),\n            ignoreExpiration: true,\n            secretOrKey: JWT_SECRET,\n        });\n    }\n    async validate(payload) {\n        const { JWT_SECRET } = process.env;\n        const { secret } = payload;\n        if (secret !== JWT_SECRET) {\n            throw new common_1.UnauthorizedException();\n        }\n        return { secret };\n    }\n};\nJwtStrategy = __decorate([\n    (0, common_1.Injectable)(),\n    __metadata(\"design:paramtypes\", [])\n], JwtStrategy);\nexports.JwtStrategy = JwtStrategy;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/auth/strategies/jwt.strategy.ts?");

/***/ }),

/***/ "./src/config/module.config.ts":
/*!*************************************!*\
  !*** ./src/config/module.config.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.ConfigModuleForRoot = void 0;\nconst config_1 = __webpack_require__(/*! @nestjs/config */ \"@nestjs/config\");\nconst ConfigModuleForRoot = () => {\n    const { NODE_ENV } = process.env;\n    return config_1.ConfigModule.forRoot({\n        envFilePath: NODE_ENV ? `${process.cwd()}/.env.${NODE_ENV}` : `${process.cwd()}/.env`,\n        isGlobal: true\n    });\n};\nexports.ConfigModuleForRoot = ConfigModuleForRoot;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/config/module.config.ts?");

/***/ }),

/***/ "./src/lambda.ts":
/*!***********************!*\
  !*** ./src/lambda.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.handler = void 0;\nconst aws_serverless_express_1 = __webpack_require__(/*! aws-serverless-express */ \"aws-serverless-express\");\nconst middleware_1 = __webpack_require__(/*! aws-serverless-express/middleware */ \"aws-serverless-express/middleware\");\nconst core_1 = __webpack_require__(/*! @nestjs/core */ \"@nestjs/core\");\nconst platform_express_1 = __webpack_require__(/*! @nestjs/platform-express */ \"@nestjs/platform-express\");\nconst app_module_1 = __webpack_require__(/*! ./app.module */ \"./src/app.module.ts\");\nconst cors_1 = __webpack_require__(/*! ./middleware/cors */ \"./src/middleware/cors.ts\");\nconst express = __webpack_require__(/*! express */ \"express\");\nconst binaryMimeTypes = [];\nlet cachedServer;\nasync function bootstrapServer() {\n    if (!cachedServer) {\n        const expressApp = express();\n        const nestApp = await core_1.NestFactory.create(app_module_1.AppModule, new platform_express_1.ExpressAdapter(expressApp));\n        nestApp.use((0, middleware_1.eventContext)());\n        nestApp.enableCors({ origin: true });\n        nestApp.use(cors_1.default);\n        await nestApp.init();\n        cachedServer = (0, aws_serverless_express_1.createServer)(expressApp, undefined, binaryMimeTypes);\n    }\n    return cachedServer;\n}\nconst handler = async (event, context) => {\n    cachedServer = await bootstrapServer();\n    return (0, aws_serverless_express_1.proxy)(cachedServer, event, context, 'PROMISE').promise;\n};\nexports.handler = handler;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/lambda.ts?");

/***/ }),

/***/ "./src/middleware/cors.ts":
/*!********************************!*\
  !*** ./src/middleware/cors.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nconst cors = (req, res, next) => {\n    const { NODE_ENV } = process.env;\n    if (NODE_ENV === 'production') {\n        const origin = req.headers.origin;\n        res.header('Access-Control-Allow-Origin', origin);\n    }\n    else {\n        res.header('Access-Control-Allow-Origin', '*');\n    }\n    res.header('Access-Control-Allow-Headers', '*');\n    res.statusCode = 200;\n    next();\n};\nexports[\"default\"] = cors;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/middleware/cors.ts?");

/***/ }),

/***/ "./src/pipes/validation.pipe.ts":
/*!**************************************!*\
  !*** ./src/pipes/validation.pipe.ts ***!
  \**************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.exceptionFactory = exports.ValidationPipe = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst class_validator_1 = __webpack_require__(/*! class-validator */ \"class-validator\");\nconst class_transformer_1 = __webpack_require__(/*! class-transformer */ \"class-transformer\");\nlet ValidationPipe = class ValidationPipe {\n    async transform(value, { metatype }) {\n        const object = (0, class_transformer_1.plainToClass)(metatype, value);\n        const errors = await (0, class_validator_1.validate)(object, {\n            whitelist: true,\n            forbidNonWhitelisted: true\n        });\n        if (errors.length > 0) {\n            let messages = [];\n            errors.forEach(error => messages = [...messages, ...Object.values(error.constraints)]);\n            throw new common_1.BadRequestException(messages);\n        }\n        return value;\n    }\n};\nValidationPipe = __decorate([\n    (0, common_1.Injectable)()\n], ValidationPipe);\nexports.ValidationPipe = ValidationPipe;\nconst wrapErrorChildren = (error, messages) => {\n    var _a;\n    if ((_a = error === null || error === void 0 ? void 0 : error.children) === null || _a === void 0 ? void 0 : _a.length) {\n        error === null || error === void 0 ? void 0 : error.children.map((error) => wrapErrorChildren(error, messages));\n    }\n    if (Object.keys((error === null || error === void 0 ? void 0 : error.constraints) || {}).length) {\n        Object.keys(error === null || error === void 0 ? void 0 : error.constraints).map((key) => {\n            messages.push(error.constraints[key]);\n        });\n    }\n};\nconst exceptionFactory = (validationErrors = []) => {\n    const messages = [];\n    validationErrors.map((error) => wrapErrorChildren(error, messages));\n    return new common_1.BadRequestException({ message: messages.join(', ') });\n};\nexports.exceptionFactory = exceptionFactory;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/pipes/validation.pipe.ts?");

/***/ }),

/***/ "./src/provider/helper.ts":
/*!********************************!*\
  !*** ./src/provider/helper.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.getHtmlRendered = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst ejs = __webpack_require__(/*! ejs */ \"ejs\");\nconst path = __webpack_require__(/*! path */ \"path\");\nconst getHtmlRendered = async (fileName, body) => {\n    try {\n        const { SERVERLESS } = process.env;\n        console.log('SERVERLESS: ', SERVERLESS);\n        const pathJoint = path.join(process.cwd(), `${!SERVERLESS ? '/dist' : ''}/templates/${fileName}.html`);\n        const html = await ejs.renderFile(pathJoint, body);\n        return html;\n    }\n    catch (err) {\n        console.log('err: ', err);\n        throw new common_1.InternalServerErrorException(err);\n    }\n};\nexports.getHtmlRendered = getHtmlRendered;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/provider/helper.ts?");

/***/ }),

/***/ "./src/provider/provider.controller.ts":
/*!*********************************************!*\
  !*** ./src/provider/provider.controller.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nvar __metadata = (this && this.__metadata) || function (k, v) {\n    if (typeof Reflect === \"object\" && typeof Reflect.metadata === \"function\") return Reflect.metadata(k, v);\n};\nvar __param = (this && this.__param) || function (paramIndex, decorator) {\n    return function (target, key) { decorator(target, key, paramIndex); }\n};\nvar _a, _b, _c, _d;\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.ProviderController = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst config_1 = __webpack_require__(/*! @nestjs/config */ \"@nestjs/config\");\nconst nestjs_sendgrid_1 = __webpack_require__(/*! @ntegral/nestjs-sendgrid */ \"@ntegral/nestjs-sendgrid\");\nconst jwt_auth_guard_1 = __webpack_require__(/*! ../auth/strategies/jwt-auth.guard */ \"./src/auth/strategies/jwt-auth.guard.ts\");\nconst validation_pipe_1 = __webpack_require__(/*! ../pipes/validation.pipe */ \"./src/pipes/validation.pipe.ts\");\nconst provider_1 = __webpack_require__(/*! ../validation/provider */ \"./src/validation/provider/index.ts\");\nconst helper_1 = __webpack_require__(/*! ./helper */ \"./src/provider/helper.ts\");\nlet ProviderController = class ProviderController {\n    constructor(configService, sendgrid) {\n        this.configService = configService;\n        this.sendgrid = sendgrid;\n    }\n    async send(body) {\n        const { items } = body;\n        console.log('body: ', body);\n        try {\n            const { SRBARRIGA_URL, DEFAULT_FROM_EMAIL, DEFAULT_CC_EMAIL } = process.env;\n            const emailsToSent = [];\n            for (let i = 0; i < items.length; i++) {\n                const { providerEmail, providerName, paymentId, } = items[i];\n                const paymentLink = `${SRBARRIGA_URL}/public-pages/payment/${paymentId}`;\n                const sendFilesLink = `${SRBARRIGA_URL}/public-pages/payment/${paymentId}?sendFiles=true`;\n                const html = await (0, helper_1.getHtmlRendered)('providerPayment', {\n                    providerName,\n                    paymentLink,\n                    sendFilesLink\n                });\n                emailsToSent.push({\n                    to: providerEmail,\n                    from: DEFAULT_FROM_EMAIL,\n                    subject: `bem.care - Folha de recebimento`,\n                    html,\n                    cc: DEFAULT_CC_EMAIL\n                });\n            }\n            await new Promise((resolve, reject) => {\n                this.sendgrid.send(emailsToSent, true, (err, result) => {\n                    console.log('err, result: ', err, result);\n                    if (err)\n                        return reject(err);\n                    return resolve(result);\n                });\n            });\n        }\n        catch (err) {\n            throw new common_1.InternalServerErrorException(err);\n        }\n    }\n};\n__decorate([\n    (0, common_1.Post)('send-payment'),\n    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),\n    (0, common_1.UsePipes)(new validation_pipe_1.ValidationPipe()),\n    __param(0, (0, common_1.Body)()),\n    __metadata(\"design:type\", Function),\n    __metadata(\"design:paramtypes\", [typeof (_a = typeof provider_1.SendPaymentInput !== \"undefined\" && provider_1.SendPaymentInput) === \"function\" ? _a : Object]),\n    __metadata(\"design:returntype\", typeof (_b = typeof Promise !== \"undefined\" && Promise) === \"function\" ? _b : Object)\n], ProviderController.prototype, \"send\", null);\nProviderController = __decorate([\n    (0, common_1.Controller)('provider'),\n    __param(1, (0, nestjs_sendgrid_1.InjectSendGrid)()),\n    __metadata(\"design:paramtypes\", [typeof (_c = typeof config_1.ConfigService !== \"undefined\" && config_1.ConfigService) === \"function\" ? _c : Object, typeof (_d = typeof nestjs_sendgrid_1.SendGridService !== \"undefined\" && nestjs_sendgrid_1.SendGridService) === \"function\" ? _d : Object])\n], ProviderController);\nexports.ProviderController = ProviderController;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/provider/provider.controller.ts?");

/***/ }),

/***/ "./src/provider/provider.module.ts":
/*!*****************************************!*\
  !*** ./src/provider/provider.module.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.ProviderModule = void 0;\nconst common_1 = __webpack_require__(/*! @nestjs/common */ \"@nestjs/common\");\nconst module_config_1 = __webpack_require__(/*! ../config/module.config */ \"./src/config/module.config.ts\");\nconst provider_controller_1 = __webpack_require__(/*! ./provider.controller */ \"./src/provider/provider.controller.ts\");\nconst nestjs_sendgrid_1 = __webpack_require__(/*! @ntegral/nestjs-sendgrid */ \"@ntegral/nestjs-sendgrid\");\n(0, module_config_1.ConfigModuleForRoot)();\nconst { SENDGRID_API_KEY } = process.env;\nlet ProviderModule = class ProviderModule {\n};\nProviderModule = __decorate([\n    (0, common_1.Module)({\n        imports: [\n            (0, module_config_1.ConfigModuleForRoot)(),\n            nestjs_sendgrid_1.SendGridModule.forRoot({\n                apiKey: SENDGRID_API_KEY,\n            }),\n        ],\n        controllers: [provider_controller_1.ProviderController],\n        providers: [provider_controller_1.ProviderController],\n        exports: [provider_controller_1.ProviderController]\n    })\n], ProviderModule);\nexports.ProviderModule = ProviderModule;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/provider/provider.module.ts?");

/***/ }),

/***/ "./src/validation/provider/index.ts":
/*!******************************************!*\
  !*** ./src/validation/provider/index.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {\n    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;\n    if (typeof Reflect === \"object\" && typeof Reflect.decorate === \"function\") r = Reflect.decorate(decorators, target, key, desc);\n    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;\n    return c > 3 && r && Object.defineProperty(target, key, r), r;\n};\nvar __metadata = (this && this.__metadata) || function (k, v) {\n    if (typeof Reflect === \"object\" && typeof Reflect.metadata === \"function\") return Reflect.metadata(k, v);\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.SendPaymentInput = exports.SendPayment = void 0;\nconst class_validator_1 = __webpack_require__(/*! class-validator */ \"class-validator\");\nconst class_transformer_1 = __webpack_require__(/*! class-transformer */ \"class-transformer\");\nclass SendPayment {\n}\n__decorate([\n    (0, class_validator_1.IsEmail)(),\n    __metadata(\"design:type\", String)\n], SendPayment.prototype, \"providerEmail\", void 0);\n__decorate([\n    (0, class_validator_1.IsString)(),\n    __metadata(\"design:type\", String)\n], SendPayment.prototype, \"providerName\", void 0);\n__decorate([\n    (0, class_validator_1.IsString)(),\n    __metadata(\"design:type\", String)\n], SendPayment.prototype, \"paymentId\", void 0);\nexports.SendPayment = SendPayment;\nclass SendPaymentInput {\n}\n__decorate([\n    (0, class_validator_1.IsArray)(),\n    (0, class_validator_1.ValidateNested)({ each: true }),\n    (0, class_transformer_1.Type)(() => SendPayment),\n    __metadata(\"design:type\", Array)\n], SendPaymentInput.prototype, \"items\", void 0);\nexports.SendPaymentInput = SendPaymentInput;\n\n\n//# sourceURL=webpack://bemcare-mailer/./src/validation/provider/index.ts?");

/***/ }),

/***/ "@nestjs/common":
/*!*********************************!*\
  !*** external "@nestjs/common" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@nestjs/common");

/***/ }),

/***/ "@nestjs/config":
/*!*********************************!*\
  !*** external "@nestjs/config" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@nestjs/config");

/***/ }),

/***/ "@nestjs/core":
/*!*******************************!*\
  !*** external "@nestjs/core" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("@nestjs/core");

/***/ }),

/***/ "@nestjs/jwt":
/*!******************************!*\
  !*** external "@nestjs/jwt" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("@nestjs/jwt");

/***/ }),

/***/ "@nestjs/passport":
/*!***********************************!*\
  !*** external "@nestjs/passport" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@nestjs/passport");

/***/ }),

/***/ "@nestjs/platform-express":
/*!*******************************************!*\
  !*** external "@nestjs/platform-express" ***!
  \*******************************************/
/***/ ((module) => {

module.exports = require("@nestjs/platform-express");

/***/ }),

/***/ "@ntegral/nestjs-sendgrid":
/*!*******************************************!*\
  !*** external "@ntegral/nestjs-sendgrid" ***!
  \*******************************************/
/***/ ((module) => {

module.exports = require("@ntegral/nestjs-sendgrid");

/***/ }),

/***/ "aws-serverless-express":
/*!*****************************************!*\
  !*** external "aws-serverless-express" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = require("aws-serverless-express");

/***/ }),

/***/ "aws-serverless-express/middleware":
/*!****************************************************!*\
  !*** external "aws-serverless-express/middleware" ***!
  \****************************************************/
/***/ ((module) => {

module.exports = require("aws-serverless-express/middleware");

/***/ }),

/***/ "class-transformer":
/*!************************************!*\
  !*** external "class-transformer" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("class-transformer");

/***/ }),

/***/ "class-validator":
/*!**********************************!*\
  !*** external "class-validator" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("class-validator");

/***/ }),

/***/ "ejs":
/*!**********************!*\
  !*** external "ejs" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("ejs");

/***/ }),

/***/ "express":
/*!**************************!*\
  !*** external "express" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("express");

/***/ }),

/***/ "passport-jwt":
/*!*******************************!*\
  !*** external "passport-jwt" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("passport-jwt");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/lambda.ts");
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;